
// Question : Write a program which takes array and return 2nd hightest number. 

/***
 * 
 * Example: If array is "[12,3,66,80,54]" then the output should be: 66.
 */

const myArray = [12,3,66,80,54];
