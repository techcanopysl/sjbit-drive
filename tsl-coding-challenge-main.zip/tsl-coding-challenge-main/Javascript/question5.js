console.log('HO Q5')

// Question : Write a program which takes a number and start counting from there to zero . 

/***
 * 
 * Example: If given number is 10 then counting start 10,9,8.......0.
 */

let counts = setInterval(functionName, 1000);
let upto = 8;


