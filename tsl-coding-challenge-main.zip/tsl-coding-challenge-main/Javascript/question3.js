
// Question : Write a program which takes array and removes falsy values (i.e. null,undefined,"",0,false), also remove duplicate value . 

/***
 * 
 * Example: If array is "[12,3,66,80,54,null,100,undefined,0]" then the output should be: 66.
 */

const myArray = [12,3,66,80,54,null,100,undefined,0,null,80,3,'c','d','c','d'];

