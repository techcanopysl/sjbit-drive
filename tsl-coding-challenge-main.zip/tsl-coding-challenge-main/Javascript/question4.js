console.log('HO Q4')

// Question : Write a program which takes a number and return table respected to number . 

/***
 * 
 * Example: If given number is 8 then output should be [8,16,24,32,40,..upto...80].
 */


const myNumber = 12;


