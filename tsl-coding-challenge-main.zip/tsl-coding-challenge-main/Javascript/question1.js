
// Question : Write a program which takes input as string and then implements the logic to reverse this string. 

/***
 * Reverse String 
 * Example: If string is "hello" then the output should be: olleh.
 */

const myStr = "hello"

