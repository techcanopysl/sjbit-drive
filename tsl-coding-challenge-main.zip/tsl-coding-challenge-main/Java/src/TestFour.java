/*
Write a program that creates an ArrayList which can hold Integers.
Enter the number of integers that will be inserted, then enter those integers.
Find the largest record from the list

For example:
Input:
3

1
2
3

Output:
The largest value: 3
 */

import java.util.*;

class TestFour {

    public static void main(String args[]){
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> al = new ArrayList<Integer>();
        System.out.println("Enter the number of integers that will be inserted: ");
        int size = scanner.nextInt();
        System.out.println("Enter some integers to insert to the ArrayList: ");
        while (size-- > 0) {
            al.add(scanner.nextInt());
        }
        int max = Integer.MIN_VALUE;
        /*write down your logic here*/

        /*write down your logic here*/
        System.out.println("The largest value: " + max);
    }
}
