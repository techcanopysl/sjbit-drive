/*
4. Write a method maxLength that takes an ArrayList of 5 Strings as a parameter and that returns the length of the
longest string in the list.
Enter 5 Strings to store in arraylist:
 pr
 ogr
 amr
 node
 s
 Output:
Length of longest string in arraylist : 4
*/

import java.util.Scanner;
import java.util.ArrayList;

class TestThree {
    static int max = 0;
    public static void main(String args[]){
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> arrayList = new ArrayList<String>();
        int size=5;
        System.out.println("Enter 5 Strings to store in arraylist:");
        while (size-- > 0) {
            arrayList.add(scanner.next());
        }
        System.out.println("The largest value: " + maxLength(arrayList));
    }

    static int maxLength(ArrayList<String> list){
        /*write down your logic here*/

        /*write down your logic here*/
        return max;
    }
}