/*
3 . Complete the following program of statement reverse. Program will take
    string as an input and will print it in reverse form like given below:

    Example:
    Java is Programing Language

    Reverse is:
    Language Programing is Java
 */

import java.io.*;
import java.util.Scanner;

public class TestTwo {
    public static void main(String a[]) throws Exception
    {
        String strarr[];
        String reverseString="";
        Scanner sc=new Scanner(System.in);
        System.out.println("Please enter the statement");
        String str = sc.nextLine();
        System.out.println("The reverse is:");
        /*write down your logic here*/

        /*write down your logic here*/
        System.out.println(reverseString);
    }
}