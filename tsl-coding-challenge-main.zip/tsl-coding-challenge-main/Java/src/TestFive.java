/*
5. Complete the following program which takes input as a number and converts it into string format.
   Initially arrays of string are given just use it for your logic.
   Scenario will be:

   Enter the number:
   54
   Entered number is:
   fifty four
*/

import java.io.*;
import java.util.Scanner;

public class TestFive {
    public static String ones[]={"zero","one","two","three","four","five","six"," seven", "eight","nine","ten","eleven","twelve","thirteen","forteen","fifteen","sixteen","seventeen","eighteen","ninteen"};
    public static String tens[]={"","","twenty","thirty","fourty","fifty","sixty","seventy","eighty","ninty"};
    public static void main(String str[]) throws Exception
    {
        Scanner sc=new Scanner(System.in);
        int num,remainder,quiescent;
        System.out.println("Enter the number:");
        num=sc.nextInt();
        System.out.println("Entered number is:");
        /*write down your logic here*/


        /*write down your logic here*/
    }//main ends
}