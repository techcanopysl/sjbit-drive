/*Question:
 Write a program which takes input as string and then implements the logic to reverse this string.
 Example:
  1. If string is "programr" then the output should be:
  rmargorp

  2.If string is "helloworld" then the output should be:
   dlrowolleh
*/

public class TestOne {
    /*write down your logic here*/

    /*write down your logic here*/
}
