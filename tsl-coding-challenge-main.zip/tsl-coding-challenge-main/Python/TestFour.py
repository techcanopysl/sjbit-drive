"""
Find the largest record from the list
"""


heights = [100, 2, 300, 10, 11, 1000, 1001]
largest_number = 0
# write down your logic here


# write down your logic here
print(largest_number)