"""
Write a program to find out the longest word in the sentence input by the user.

Input: This site is for programming in a lot of languages
Output: programming
"""

# write down your logic here

# write down your logic here

# Driver Code
if __name__ == "__main__":
    str = "be confident and be yourself"
    l = list(str.split(" "))
    largestWord(l)