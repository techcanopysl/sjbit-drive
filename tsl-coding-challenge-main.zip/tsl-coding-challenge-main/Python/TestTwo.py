"""
Write a program to reverse the sentence wordwise.

Input:
You have entered a wrong domain
Output:
domain wrong a entered have You
"""

inp = raw_input()
# write down your logic here


#
print(reversed)
