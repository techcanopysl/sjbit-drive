ones = ['', 'One',  'Two',  'Three',  'Four',  'Five', \
            'Six', 'Seven',  'Eight',  'Nine', 'Ten', \
            'Eleven', 'Twelve', 'Thirteen',  'Fourteen', \
            'Fifteen', 'Sixteen',  'Seventeen', 'Eighteen', 'Nineteen']
tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety']

# write down your logic here

# write down your logic here

def main():
    num = eval(input("Please enter a number between 0 and 99: "))
    print(number(num))
main()